import sys
import os
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmc
import urllib.request
from urllib.parse import urljoin
import ssl
import json

if len(sys.argv) > 1:
    HANDLE = int(sys.argv[1])
else:
    HANDLE = -1
# Addon Variables
ADDON = xbmcaddon.Addon()
ADDONTITLE = 'test addon title'
ADDON_FANART = ADDON.getAddonInfo('fanart')
ADDON_PATH = ADDON.getAddonInfo('path')
CUSTOM_ART = os.path.join(ADDON_PATH, 'resources', 'kodi_rd_israel_art')
RD_TEXT = 'Real Debrid - סרוק את קוד ה-QR בטלפון, ולאחר מכן הזן את הקוד המוצג על המסך בתוך האתר'
TRAKT_TEXT = 'Trakt - סרוק את קוד ה-QR בטלפון, ולאחר מכן הזן את הקוד המוצג על המסך בתוך האתר'
# Images used for the contact window.  http:// for default icon and fanart
CONTACTICON = os.path.join(CUSTOM_ART, 'qr_real_debrid_add_device.jpg')
# Themes
THEME_TITLE = u'[COLOR {color2}]{{}}[/COLOR]'.format(color2='lightblue')
THEME_TEXT = u'[COLOR {color2}]{{}}[/COLOR]'.format(color2='yellow')

# Exit Actions
ACTION_PREVIOUS_MENU = 10  # ESC action
ACTION_NAV_BACK = 92  # Backspace action
ACTION_BACKSPACE = 110  # ?
BACK_ACTIONS = [ACTION_PREVIOUS_MENU, ACTION_NAV_BACK, ACTION_BACKSPACE]

def show_contact(rd_msg="", trakt_msg=""):
    class ContactWindow(xbmcgui.WindowXMLDialog):
        def __init__(self, *args, **kwargs):
            self.title = THEME_TITLE.format("חיבור מנוי ה-Real Debrid להרחבת Fen")
            self.image = kwargs["image"]
            self.fanart = kwargs["fanart"]
            self.rd_msg = THEME_TEXT.format(kwargs["rd_msg"])
            self.trakt_msg = THEME_TEXT.format(kwargs["trakt_msg"])

        def onInit(self):
            self.fanartimage = 101
            self.titlebox = 102
            self.imagecontrol = 103
            self.rd_textbox = 104
            self.trakt_textbox = 108
            self.scrollcontrol = 105
            self.fen_connect_rd_button = 106
            self.fen_connect_trakt_button = 107
            self.show_dialog()

        def show_dialog(self):
            self.getControl(self.imagecontrol).setImage(self.image)
            self.getControl(self.fanartimage).setImage(self.fanart)
            self.getControl(self.fanartimage).setColorDiffuse('9FFFFFFF')
            self.getControl(self.rd_textbox).setText(self.rd_msg)
            self.getControl(self.trakt_textbox).setText(self.trakt_msg)
            self.getControl(self.titlebox).setLabel(self.title)
            self.setFocusId(self.fen_connect_rd_button)

        def onClick(self, controlid):
            if controlid == self.fen_connect_rd_button:
                self.close()
                # Open Fen Real Debrid Authentication Window
                xbmc.executebuiltin('RunPlugin(plugin://plugin.video.fen/?mode=real_debrid.authenticate)')
            elif controlid == self.fen_connect_trakt_button:
                self.close()
                # Open Fen Trakt Authentication Window
                xbmc.executebuiltin('RunPlugin(plugin://plugin.video.fen/?mode=trakt.trakt_authenticate)')

        def onAction(self, action):
            if action.getId() in BACK_ACTIONS:
                self.close()

    cw = ContactWindow("Contact.xml", ADDON_PATH, 'Default', title=ADDONTITLE, fanart=ADDON_FANART,
                  image=CONTACTICON, rd_msg=RD_TEXT, trakt_msg=TRAKT_TEXT)
    cw.doModal()
    del cw

def main():
    show_contact(rd_msg="",trakt_msg="")

if __name__ == "__main__":
    main()
    if HANDLE > -1:
        xbmcplugin.endOfDirectory(HANDLE)
