# -*- coding: utf-8 -*-
from xbmc import executebuiltin

executebuiltin('RunPlugin(plugin://plugin.video.twilight/?mode=kodi_refresh)')
