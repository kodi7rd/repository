
import time,re,xbmcaddon
import xbmc,xbmcgui
import os,json
from resources.modules import cache
from resources.modules import log
from resources.modules.engine import get_subtitles,download_sub
from urllib.parse import  unquote_plus, unquote,  quote
from resources.modules.general import get_video_data,get_db_data,MySubFolder,notify,Thread,show_results,save_file_name
from urllib.parse import parse_qsl

import urllib.parse
from resources.modules import general
from resources.sources import bsplayer
from resources.sources import ktuvit
from resources.sources import opensubtitles
from resources.sources import subscene
from resources.sources import wizdom

MyScriptName = xbmcaddon.Addon().getAddonInfo('name')
MyScriptID = xbmcaddon.Addon().getAddonInfo('id')
unque=urllib.parse.unquote_plus
monit = xbmc.Monitor()
ab_req=monit.abortRequested()
log.warning('Starting %s Service!!!'%MyScriptName)
global video_id
video_id=""
trigger=True

def isExcluded(movieFullPath):
    excluded_addons=['idanplus','sdarot.tv','youtube','kids_new']
    if (movieFullPath.find("pvr://") > -1) :
        log.warning("isExcluded(): Video is playing via Live TV, which is currently set as excluded location.")
        return False
    if (xbmc.getInfoLabel("VideoPlayer.mpaa")=='heb'):
          log.warning("isExcluded(): mpaa!!." )
          return False
    if any(x in current_list_item.lower() for x in excluded_addons):
            log.warning("isExcluded(): Video is playing from '%s', which is currently set as !!excluded_addons!!."%x )
            return False
    if ',' in  Addon.getSetting('ExcludeAddos'):
        ExcludeAddos = Addon.getSetting('ExcludeAddos').split(',')  
    else:
        ExcludeAddos = [Addon.getSetting('ExcludeAddos')]
    for items in ExcludeAddos:
        if items.lower() in current_list_item.lower():
            log.warning("isExcluded(): Video is playing from '%s', which is currently set as !!excluded_addons!!."%items )
            return False
    
def place_sub(f_result):
    last_sub_index,all_subs=get_db_data(f_result)
    selected_sub=f_result[0]
    for items in f_result:
        if (last_sub_index==items[8]):
            selected_sub=items
            break
    params=get_params(selected_sub[4])
    download_data=unque(params["download_data"])
    download_data=json.loads(download_data)
    source=(params["source"])
    language=(params["language"])
    filename=unque(params["filename"])
    sub_file=download_sub(source,download_data,MySubFolder,language,filename)
    log.warning('Auto Sub result:'+str(sub_file))
    xbmc.sleep(100)
    xbmc.Player().setSubtitles(sub_file)
    save_file_name(params["filename"])
    return (str(selected_sub[5])+ "% "+selected_sub[1])
def get_params(url):

    param = dict(parse_qsl(url.replace('?','')))
    return param
    

while not ab_req:
    video_data={}
    try:
        Addon=xbmcaddon.Addon()
    except:
        sys.exit()
    ExcludeTime = int((Addon.getSetting('ExcludeTime')))*60
    if (xbmc.Player().isPlaying()):
        video_data=get_video_data()
        pre_video_id=video_id
        video_id=video_data['OriginalTitle']+video_data['Tagline']+video_data['imdb']+str(video_data['season'])+str(video_data['episode'])
        
        if (video_id!=pre_video_id):
            
            
            trigger=True
        pre_video_id=video_id
    else:
        trigger=False
        video_data['mpaa']='heb'
        video_id=""
    current_list_item=""
    current_list_item_temp=(xbmc.getInfoLabel("ListItem.FileNameAndPath"))
    if len(current_list_item_temp)>0 and (('plugin://') in current_list_item_temp or ('smb://') in current_list_item_temp):
                      
            regex='//(.+?)/'
            match=re.compile(regex).findall(current_list_item_temp)
            if len (match)>0:
               current_list_item=match[0]
            else:
               current_list_item=current_list_item_temp
    if (xbmc.Player().isPlaying()) and trigger:
        totalTime=0
        
        
        vidtime = xbmc.Player().getTime()
        if vidtime>0:
            totalTime = xbmc.Player().getTotalTime()
        force_download=True
        if  Addon.getSetting("force")=='true':
          force_download=True
        if  Addon.getSetting("force")=='false' and xbmc.getCondVisibility("VideoPlayer.HasSubtitles"):
          force_download=False
        
        
        log.warning('current_list_item::'+str(current_list_item))
        if Addon.getSetting("autosub")=='true':
          
          
          
          if totalTime > ExcludeTime and force_download==True and video_data['mpaa']!='heb':
           
            if  Addon.getSetting("pause")=='true':
                xbmc.Player().pause()
            from resources.modules import general
            general.show_msg="מוריד כתוביות"
            general.with_dp=False
            thread=[]
                    
            thread.append(Thread(show_results))

            thread[0].start()
            try:
                f_result=cache.get(get_subtitles,24,video_data,table='subs')
                sub_name=place_sub(f_result)
            except Exception as e:
                notify(str(e))
            
            
            if  Addon.getSetting("pause")=='true':
                xbmc.Player().pause()
            
            trigger=False
            general.show_msg="[COLOR lightblue]כתובית מוכנה[/COLOR]"
            xbmc.sleep(1000)
            general.show_msg="END"
    
    xbmc.sleep(1000)
    
  