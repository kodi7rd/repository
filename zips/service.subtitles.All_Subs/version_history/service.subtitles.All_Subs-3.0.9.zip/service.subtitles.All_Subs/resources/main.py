# -*- coding: utf-8 -*-
import sys,xbmcgui,xbmcplugin,xbmc,xbmcaddon
from urllib.parse import parse_qsl
from resources.modules.general import get_video_data,MyScriptID
from resources.modules import log
from resources.modules import cache
import urllib.parse
import json
global from_autosub
from_autosub=False
def c_get_subtitles(video_data):
    global from_autosub
    from resources.modules.engine import get_subtitles
    from resources.modules.general import notify,Thread,show_results
    from resources.modules import general
    if from_autosub:
        general.with_dp=False
    else:
        general.with_dp=True
    from_autosub=False
    general.show_msg="מחפש כתוביות"
    log.warning(general.show_msg)
    thread=[]
                
    thread.append(Thread(show_results))

    thread[0].start()
        
    f_result=get_subtitles(video_data)
    
    general.show_msg="END"
    return f_result
def get_params_single(url):

    param = dict(parse_qsl(url.replace('?','')))
    return param
def display_subtitle(f_result,video_data,last_sub_index,all_subs):
    
    all_d=[]

    for items in f_result:
            try:
                val=all_subs[items[8]]
              
            except:
                val=None
                pass
            
            if (last_sub_index==items[8]):
                added_string='[COLOR deepskyblue][B][I]>> '
            elif val:
                added_string='[COLOR deepskyblue][B][I]'
            else:
                added_string='[COLOR gold]'
            if xbmc.Player().isPlaying():
                sub_name=added_string+str(items[5])+ "% "+'[/COLOR]'+items[1]
                if ('[B][I]' in added_string):
                    sub_name=sub_name+'[/I][/B]'
                if video_data['file_original_path'].replace("."," ").lower() in items[1].replace("."," ").lower() and len(video_data['file_original_path'].replace("."," "))>5 or items[5]>80:
                         #json_value['label2']='[COLOR gold] GOLD [B]'+json_value['label2']+'[/B][/COLOR]'
                         sub_name='[COLOR gold] GOLD [B]'+sub_name+'[/B][/COLOR]'
            else:
                sub_name=items[1]
            try:
                  listitem = xbmcgui.ListItem(label          = items[0],
                                                label2         = sub_name,
                                                iconImage      = items[2],
                                               
                                                thumbnailImage = items[3]
                                                )
            except:
                listitem = xbmcgui.ListItem(label          = items[0],
                                                label2         = sub_name
                                                
                                                )
            listitem.setArt({'thumb' : items[3], 'icon': items[2]})
            listitem.setProperty( "sync", items[6] )
            listitem.setProperty( "hearing_imp",items[7] )
            all_d.append((items[4],listitem,False))
            #xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=str(items['url']), listitem=listitem, isFolder=False)
    listitem = xbmcgui.ListItem(label="פתח הגדרות הרחבה",label2='[COLOR plum][I]'+ "פתח הגדרות הרחבה"+'[/I][/COLOR]')
    url = "plugin://%s/?action=open_settings" % (MyScriptID)
    all_d.append((url,listitem,True))
    
    listitem = xbmcgui.ListItem(label="ניקוי",label2='[COLOR khaki][I]'+"אפס את נתוני המטמון של התוסף"+'[/I][/COLOR]')
    url = "plugin://%s/?action=clean" % (MyScriptID)
    all_d.append((url,listitem,True))

    listitem = xbmcgui.ListItem(label="בטל כתוביות",label2='[COLOR seagreen][I]'+ "בטל כתוביות"+'[/I][/COLOR]')
    url = "plugin://%s/?action=disable_subs"% (MyScriptID)
    all_d.append((url,listitem,True))
    
    listitem = xbmcgui.ListItem(label="פתח חלון כתוביות",label2='[COLOR lightblue][I]'+ "חלון כתוביות"+'[/I][/COLOR]')
    url = "plugin://%s/?action=sub_window"% (MyScriptID)
    all_d.append((url,listitem,True))
    
    
    return all_d
    
def get_params():
 
    try:
        param = dict(parse_qsl(sys.argv[2].replace('?','')))
    except:
        
        param={}
        param['action']=sys.argv[1]
    return param
def get_db_data(f_result):
    log.warning(f_result)
    import os,xbmcvfs
    xbmc_tranlate_path=xbmcvfs.translatePath
    user_dataDir = xbmc_tranlate_path(xbmcaddon.Addon().getAddonInfo("profile"))
    if not os.path.exists(user_dataDir):
         os.makedirs(user_dataDir)
     
    try:
      from sqlite3 import dbapi2 as database
    except:
      from pysqlite2 import dbapi2 as database
    cacheFile=os.path.join(user_dataDir,'database.db')
    dbcon = database.connect(cacheFile)
    dbcur = dbcon.cursor()
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT );" % ('list_sub'))
    dbcur.execute("SELECT * FROM list_sub")
    list_sub = dbcur.fetchall()
    dbcur.close()
    dbcon.close()
    all_subs={}
    last_sub_index=''
    x=0
    for i in list_sub:
        all_subs[i[0]]=x
        x+=1
    max_index=0
    for items in f_result:
        c_sub_name=items[8]
        
        try:
            val=all_subs[c_sub_name]
            a_index=val
            if a_index>max_index:
                last_sub_index=c_sub_name
                max_index=a_index
        except:
            pass
    return last_sub_index,all_subs
def c_sort_subtitles(f_result,video_data):
    from resources.modules.engine import sort_subtitles
    x=sort_subtitles(f_result,video_data)
    return x
def start():
    if len(sys.argv) >= 2: 
        params = get_params()

        video_data=get_video_data()
        log.warning(params)
        action=None
        unque=urllib.parse.unquote_plus
        que=urllib.parse.quote_plus
        
        try:        
            action=(params["action"])
        except:
                pass
        try:
            download_data=unque(params["download_data"])
            download_data=json.loads(download_data)
        except:
            pass
        try:
            source=(params["source"])
        except:
            pass
        try:
            filename=unque(params["filename"])
        except:
            pass
        try:
            language=(params["language"])
        except:
            pass
        log.warning('action:'+action)
        if action=='search':
            
            
            log.warning('Searching for:')
            
            file_org=video_data['file_original_path']
            video_data.pop('file_original_path')
            
            f_result=cache.get(c_get_subtitles,24,video_data,table='subs')
            video_data['file_original_path']=file_org
            
            f_result=cache.get(c_sort_subtitles,24,f_result,video_data,table='subs')
            last_sub_index,all_subs=get_db_data(f_result)
            
            if (f_result):
                
                all_d=display_subtitle(f_result,video_data,last_sub_index,all_subs)
            else:
                cache.clear(['subs'])
                
                all_d=display_subtitle({},video_data,'',[])
                
            
            
            xbmc.sleep(100)
            xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
        elif action=='download':
            import os
            
            from resources.modules.general import CachedSubFolder,save_file_name
            
            
            
            try:
                c_sub_file=os.path.join(CachedSubFolder,source+language+filename)
                if not os.path.exists(c_sub_file):
                    from resources.modules.engine import download_sub
                    import shutil
                    from resources.modules import general
                    from resources.modules.general import Thread,show_results,MySubFolder
                    general.with_dp=True
                    general.show_msg="מוריד"
                    log.warning(general.show_msg)
                    thread=[]
                                                                                        
                    thread.append(Thread(show_results))

                    thread[0].start()
                    sub_file=download_sub(source,download_data,MySubFolder,language,filename)
                    
                    log.warning(sub_file)
                    general.show_msg="END"
                    if not general.break_all:
                        listitem =  xbmcgui.ListItem(label=sub_file)
                        
                        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=sub_file, listitem=listitem,isFolder=False)
                        save_file_name(filename)
                        if (source!='bsplayer'):
                            shutil.copy(sub_file,c_sub_file)
                        
                else:
                    
                    sub_file=c_sub_file
                    listitem =  xbmcgui.ListItem(label=sub_file)
                        
                    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=sub_file, listitem=listitem,isFolder=False)
                    
                    save_file_name(filename)
            except Exception as e:
                xbmcgui.Dialog().ok('שגיאה','תקלה בהורדה \n'+str(e))    
        elif action=='open_settings':
            xbmcaddon.Addon().openSettings()
        elif action=='clean':
            from resources.modules.general import notify
            cache.clear(['subs'])
            notify( "המטמון נוקה" )
        elif action=='disable_subs':
            from resources.modules.general import notify
            xbmc.Player().setSubtitles("")
            listitem = xbmcgui.ListItem(label="a")
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="ww", listitem=listitem,isFolder=False)
            notify("כתוביות בוטלו")
        elif action=='sub_window':
            from resources.modules.sub_window import MySubs
            f_result=cache.get(c_get_subtitles,24,video_data,table='subs')
            last_sub_index,all_subs=get_db_data(f_result)
            xbmc.executebuiltin('Dialog.Close(all,true)')
            xbmc.Player().pause()
            
            
            window = MySubs('Subtitles - ' ,f_result,f_result,video_data,all_subs,last_sub_index)
        elif action=='sub_window_unpause':
            from resources.modules.sub_window import MySubs
            f_result=cache.get(c_get_subtitles,24,video_data,table='subs')
            last_sub_index,all_subs=get_db_data(f_result)
            xbmc.executebuiltin('Dialog.Close(all,true)')
            
   
            
            window = MySubs('Subtitles - ' ,f_result,f_result,video_data,all_subs,last_sub_index)
        elif action=='next':
            from resources.modules import general
            from resources.modules.general import Thread,show_results,save_file_name
            from resources.modules.engine import download_sub
            general.with_dp=False
            general.show_msg="כתובית הבאה"
            log.warning(general.show_msg)
            thread=[]
                        
            thread.append(Thread(show_results))

            thread[0].start()
        
            f_result=cache.get(c_get_subtitles,24,video_data,table='subs')
            last_sub_index,all_subs=get_db_data(f_result)
            
            next_one=False
            selected_sub=None
            for items in f_result:
                if (next_one):
                    if (last_sub_index!=items[8]):
                        selected_sub=items
                        
                        break
                    else:
                        next_one=False
                if (last_sub_index==items[8]):
                    next_one=True
                
            if selected_sub:
                from resources.modules.general import MySubFolder
                params=get_params_single(selected_sub[4])
                download_data=unque(params["download_data"])
                download_data=json.loads(download_data)
                source=(params["source"])
                language=(params["language"])
                filename=params["filename"]
                general.show_msg="מוריד"
                sub_file=download_sub(source,download_data,MySubFolder,language,filename)
                log.warning('Next Sub result:'+str(sub_file))
                general.show_msg="מוכן"
                
                xbmc.Player().setSubtitles(sub_file)
                save_file_name(params["filename"])
            else:
                general.show_msg="סוף הכתוביות"
                
            xbmc.sleep(800)
            general.show_msg="END"
        elif action=='previous':
            from resources.modules.general import MySubFolder
            from resources.modules import general
            from resources.modules.general import Thread,show_results,save_file_name
            from resources.modules.engine import download_sub
            general.with_dp=False
            general.show_msg="כתובית קודמת"
            
            thread=[]
                        
            thread.append(Thread(show_results))

            thread[0].start()
        
            f_result=cache.get(c_get_subtitles,24,video_data,table='subs')
            last_sub_index,all_subs=get_db_data(f_result)
            
            pre_one=None
            found=None
            for items in f_result:
                if (found):
                    if ((pre_one) and (last_sub_index!=pre_one[8])):
                        selected_sub=pre_one
                        
                        break
                    else:
                        found=None
                if (last_sub_index==items[8]):
                    found=True
                else:
                    pre_one=items
            log.warning('found_P:'+str(found))
            if found:
                
                params=get_params_single(selected_sub[4])
                download_data=unque(params["download_data"])
                download_data=json.loads(download_data)
                source=(params["source"])
                language=(params["language"])
                filename=params["filename"]
                sub_file=download_sub(source,download_data,MySubFolder,language,filename)
                log.warning('previous Sub result:'+str(sub_file))
                general.show_msg=sub_file
                xbmc.sleep(100)
                xbmc.Player().setSubtitles(sub_file)
                save_file_name(params["filename"])
            else:
                general.show_msg="זאת הכתובית הראשונה"
                xbmc.sleep(800)
            general.show_msg="END"
            
        try:
            xbmc.sleep(100)
            xbmcplugin.endOfDirectory(int(sys.argv[1]),updateListing =True,cacheToDisc =True)
            
        except:
            pass
        