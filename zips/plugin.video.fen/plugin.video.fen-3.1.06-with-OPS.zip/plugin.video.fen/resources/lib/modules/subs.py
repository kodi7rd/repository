########### Imports #####################
from modules import kodi_utils
import json
import re,requests
from collections import OrderedDict
from modules.kodi_utils import subs, database

# Import hebrew subtitle search functions
from kodirdil import ktuvit
from kodirdil import wizdom
from kodirdil import opensubtitles
#########################################

########### Constants ###################
subs_website_names = {
    'ktuvit_subtitles_list': '[KT]',
    'wizdom_subtitles_list': '[WIZ]',
    'opensubtitles_subtitles_list': '[OPS]'
}
#########################################

def search_subtitles(media_type, title, season, episode, year, tmdb_id):
    
    media_metadata = {
        "media_type": media_type,
        "title": title.replace("%20"," ").replace("%27","'"),
        "season": season,
        "episode": episode,
        "year": year,
        "tmdb_id": tmdb_id,
        "imdb_id": get_imdb_id(media_type, tmdb_id)
    }
    
    
    # Search for subtitles in Ktuvit website
    try:
        ktuvit_subtitles_list = ktuvit.get_hebrew_subtitles(media_metadata)
        kodi_utils.logger("KODI-RD-IL", f"ktuvit_subtitles_list: {str(ktuvit_subtitles_list)}")   
    except Exception as e:
        kodi_utils.logger("KODI-RD-IL", f"Error in searching subtitles from Ktuvit: {str(e)}")
        ktuvit_subtitles_list = []
        
        
    # Search for subtitles in Wizdom website.
    try:
        wizdom_subtitles_list = wizdom.get_hebrew_subtitles(media_metadata)
        kodi_utils.logger("KODI-RD-IL", f"wizdom_subtitles_list: {str(wizdom_subtitles_list)}")   
    except Exception as e:
        kodi_utils.logger("KODI-RD-IL", f"Error in searching subtitles from Wizdom: {str(e)}")
        wizdom_subtitles_list = []
        
        
    # Search for subtitles in OpenSubtitles website.
    try:
        opensubtitles_subtitles_list = opensubtitles.get_hebrew_subtitles(media_metadata)
        kodi_utils.logger("KODI-RD-IL", f"opensubtitles_subtitles_list: {str(opensubtitles_subtitles_list)}")   
    except Exception as e:
        kodi_utils.logger("KODI-RD-IL", f"Error in searching subtitles from OpenSubtitles: {str(e)}")
        opensubtitles_subtitles_list = []
        
        
    # Combine the contents of ktuvit_subtitles_list and wizdom_subtitles_list
    combined_subtitles_list = ktuvit_subtitles_list + wizdom_subtitles_list + opensubtitles_subtitles_list
    # Convert the combined list to an OrderedDict to remove duplicates while preserving order
    unique_subtitles_dict = OrderedDict.fromkeys(combined_subtitles_list)
    # Convert the set back to a list
    unique_subtitles_list = list(unique_subtitles_dict.keys())
    
    # Write the unique subtitles list to the subs.db cache table
    write_unique_subtitles_to_subs_db(unique_subtitles_list, ktuvit_subtitles_list, wizdom_subtitles_list, opensubtitles_subtitles_list)
    
    return unique_subtitles_list
    
    
def get_imdb_id(media_type, tmdb_id):

    imdb_api_url = f'https://api.themoviedb.org/3/{media_type}/{tmdb_id}?api_key=34142515d9d23817496eeb4ff1d223d0&append_to_response=external_ids'
    try:
        imdb_api_reponse = requests.get(imdb_api_url).json()
        imdb_id = imdb_api_reponse['external_ids'].get('imdb_id', '')
        kodi_utils.logger("KODI-RD-IL", f"get_imdb_id function: TMDb ID: {tmdb_id} | IMDb ID: {imdb_id}")
        return imdb_id
    except Exception as e:
        kodi_utils.logger("KODI-RD-IL", f"Error in getting imdb_id from TMDb API: {str(e)}")
        return ''
  
  
def write_unique_subtitles_to_subs_db(unique_subtitles_list, ktuvit_subtitles_list, wizdom_subtitles_list, opensubtitles_subtitles_list): 
    # Write the unique subtitles list to the subs.db cache table
    try:
        dbcon = database.connect(subs)
        dbcur = dbcon.cursor()
        dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""subtitle_name TEXT ,""website_name TEXT);" % ('current_subtitles_cache'))
        dbcon.commit()
        # Clear subs.db
        dbcon.execute("DELETE FROM current_subtitles_cache")
        dbcon.commit()
        
        if unique_subtitles_list:
            for subtitle_name in unique_subtitles_list:
                website_name = None
                for key in subs_website_names:
                    if subtitle_name in eval(key):
                        website_name = subs_website_names[key]
                        break
                if website_name:
                    dbcur.execute("INSERT INTO current_subtitles_cache Values ('%s','%s')"%(subtitle_name, website_name))
                    dbcon.commit()
            dbcon.close()
            kodi_utils.logger("KODI-RD-IL", f"unique_subtitles_list: {str(unique_subtitles_list)}")
        else:
            kodi_utils.logger("KODI-RD-IL", f"unique_subtitles_list is empty.")
            
    except Exception as e:
        kodi_utils.logger("KODI-RD-IL", f"Error in writing subtitles to subs.db(): {str(e)}")
    