# KODI-RD-IL ADDITION - Addition by the KODI-RD-IL team
# -*- coding: utf-8 -*- - Set the character encoding to UTF-8

import sys  # Import the sys module
import time  # Import the time module
import xbmc  # Import the xbmc module

global global_var, stop_all  # Define global variables
global_var = []  # Set global_var to an empty list
stop_all = 0  # Set stop_all to 0

import re  # Import the re module
import requests  # Import the requests module

type = ['tv', 'movie']  # Define a list called type with two elements 'tv' and 'movie'

import urllib  # Import the urllib module
import base64  # Import the base64 module
import json  # Import the json module
import logging  # Import the logging module

import zlib  # Import the zlib module
BASE_URL = "http://www.cinemast.org/he/cinemast/api/"  # Define a constant called BASE_URL with the value "http://www.cinemast.org/he/cinemast/api/"

class URLHandler():  # Define a class called URLHandler

    def __init__(self):  # Define a constructor for the class
        self.opener = urllib2.build_opener()  # Create an opener object using urllib2.build_opener()
        self.opener.addheaders = [  # Set the headers of the opener object with a list of tuples, where each tuple contains a header name and value
            ('Accept-Encoding', 'gzip'),
            ('Accept-Language', 'en-us,en;q=0.5'),
            ('Pragma', 'no-cache'),
            ('Cache-Control', 'no-cache'),
            ('User-Agent',
             'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 Kodi/17.2 (KHTML, like Gecko) Chrome/49.0.2526.111 Safari/537.36')
        ]

    def request(self, url, data=None, query_string=None, ajax=False, referrer=None, cookie=None):
        if data is not None:
            data = urllib.urlencode(data)  # Encode the data using urllib.urlencode()

        if query_string is not None:
            url += '?' + urllib.urlencode(query_string)  # Append the query string to the url using urllib.urlencode()

        if ajax:
            self.opener.addheaders += [('X-Requested-With', 'XMLHttpRequest')]  # Add an X-Requested-With header to the opener headers

        if referrer is not None:
            self.opener.addheaders += [('Referrer', referrer)]  # Add a Referrer header to the opener headers

        if cookie is not None:
            self.opener.addheaders += [('Cookie', cookie)]  # Add a Cookie header to the opener headers

        content = None  # Set content to None

        # if data is not None and 'password' not in data:
        #     logging.warning("Post Data: %s" % (data))
        try:
            response = self.opener.open(url, data, timeout=5)  # Send the request using the opener object
            content = None if response.code != 200 else response.read()  # Set content to None if the response code is not 200, otherwise set it to the response content

            if response.headers.get('content-encoding', '') == 'gzip':  # If the content-encoding header is gzip
                try:
                    content = zlib.decompress(content, 16 + zlib.MAX_WBITS)  # Decompress the content using zlib.decompress()
                except zlib.error:
                    pass

            if response.headers.get('content-type', '') == 'application/json':  # If the content-type header is application/json
                content = json.loads(content, encoding="utf-8")  # Load the JSON content using json.loads()

            response.close()  # Close the response object
        except Exception as e:
            pass  # Do nothing if an exception occurs

        return content  # Return the content

def login(notify_success=True):
    urlHandler = URLHandler()  # Create an instance of the URLHandler class
    email = Addon.getSetting("Email")  # Get the value of the Email setting using Addon.getSetting()
    password = Addon.getSetting("Password")  # Get the value of the Password setting using Addon.getSetting()

    if email == '' or password == '':  # If either the Email or Password setting is blank
        __settings__.openSettings()  # Open the addon settings
        email = Addon.getSetting("Email")  # Get the value of the Email setting using Addon.getSetting()
        password = Addon.getSetting("Password")  # Get the value of the Password setting using Addon.getSetting()

    post_data = {'username': email, 'password': password}  # Define a dictionary with the post data
    content = urlHandler.request(BASE_URL + "login/", post_data)  # Send a request to the login API using the URLHandler.request() method and the BASE_URL constant

    if content['result'] == 'success':  # If the result key in the content dictionary is 'success'
        if notify_success:
            notify(32010)  # Show a notification with the ID 32010 using the xbmcgui.Dialog().notification() method

        del content["result"]  # Remove the result key from the content dictionary
        return content  # Return the content dictionary
    else:
        notify(32009)  # Show a notification with the ID 32009 using the xbmcgui.Dialog().notification() method
        return None

def get_user_token(force_update=False):
    # results =cache.get(login, 24, False, table='pages')
    results = login(False)  # Call the login() function with the notify_success parameter set to False

    '''
    if force_update:
        store.delete('credentials')

    results = store.get('credentials')
    if results:
        results = json.loads(results)
    else:
        results = login(False)
        if results:
            store.set('credentials', json.dumps(results))
    '''

    return results  # Return the results of the login function call.

def subcenter_search(item,mode_subtitle,subtitle_list,check_one):
    # Import the regular expressions module
    import re
    
    # Initialize an empty list to store the search results
    results = []
    
    # Initialize an empty list to store the IDs of all items in the search results
    id_collection=[]
    
    # Determine the search string based on whether the item is a TV show or movie
    search_string = re.split(r'\s\(\w+\)$', item["tvshow"])[0] if item["tvshow"] else item["title"]
    
    # Get the user token
    user_token = get_user_token()
    
    # Check if a user token was retrieved
    if user_token:
        # Set up the search query based on the item type (TV show or movie)
        query = {"q": search_string.encode("utf-8"), "user": user_token["user"], "token": user_token["token"]}
        if item["tvshow"]:
            query["type"] = "series"
            query["season"] = item["season"]
            query["episode"] = item["episode"]
        else:
            query["type"] = "movies"
            if item["year"]:
                query["year_start"] = int(item["year"]) 
                query["year_end"] = int(item["year"])
        
        # Send the search query and store the results
        search_result =  urlHandler.request(BASE_URL + "search/", query)
        
        # Check if the search failed due to an authentication error
        if search_result is not None and search_result["result"] == "failed":
            # Update cached token
            user_token =  get_user_token(True)
            query["token"] = user_token["token"]
            search_result =  urlHandler.request(BASE_URL + "search/", query)
        
        # Check if the search failed for some other reason or returned no results
        if search_result is None or search_result["result"] != "success" or search_result["count"] < 1:
            # Return an empty list of search results
            return results
        
        # Store the search results
        results = search_result# _filter_results(search_result["data"], search_string, item)
    
    # Initialize some variables for later use
    ret = []
    ok=True
    lang=[]
    lang.append('he')
    results2=[]
    
    # Iterate over each search result and retrieve any available subtitles
    for result in results['data']:
        total_downloads = 0
        counter = 0
        
        # Store the subtitle data for the current search result
        subs_list = result
        
        # Check if any subtitles are available for the current search result
        if subs_list is not None:
            
            # Iterate over each available subtitle language
            for language in subs_list['subtitles']:
                
                # Check if the current language is one of the desired languages
                if language in lang:
                    
                    # Iterate over each subtitle version for the current language
                    for current in subs_list['subtitles'][language]:
                        title = current["version"]
                        
                        # Check if the current subtitle version has already been retrieved
                        if title not in subtitle_list:
                            counter += 1
                            
                            # Add the current subtitle version to the list of retrieved subtitles
                            subtitle_list.append(title)
                            
                            # Check if only one subtitle version should be retrieved
                            if check_one==True:
                                break
    
    # Return the list of retrieved subtitles
    return subtitle_list
    
def get_login_cook():
    # import the requests library, which will be used to send HTTP requests
    import requests
    # set the headers for the HTTP request
    headers = {
    'authority': 'www.ktuvit.me',
    'accept': 'application/json, text/javascript, */*; q=0.01',
    'x-requested-with': 'XMLHttpRequest',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36',
    'content-type': 'application/json',
    'origin': 'https://www.ktuvit.me',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'cors',
    'sec-fetch-dest': 'empty',
    
    'accept-language': 'en-US,en;q=0.9',
    
    }
    # set the data for the HTTP request, which includes the login credentials
    data = '{"request":{"Email":"hatzel6969@gmail.com","Password":"Jw1n9nPOZRAHw9aVdarvjMph2L85pKGx79oAAFTCsaE="}}'
    # send a POST request to the login endpoint to get a login cookie
    login_cook = requests.post('https://www.ktuvit.me/Services/MembershipService.svc/Login', headers=headers, data=data).cookies
    # create a new dictionary to store the cookies
    login_cook_fix={}
    # iterate through the cookies returned by the login endpoint and add them to the dictionary
    for cookie in login_cook:
            login_cook_fix[cookie.name]=cookie.value
    # return the dictionary of login cookies
    return login_cook_fix

def FirstPlace_Search(item,imdb_id,subtitle_list,check_one=False):
    global links_first
    import requests
    
    # get the login cookie using a separate function
    login_cook=get_login_cook()
    
    # determine whether the search is for a TV show or movie
    if "tvshow" in item:
        if item["tvshow"]:
            s_type='1'
            s_title=item["tvshow"]
    else:
        s_type='0'
        s_title=item["title"]
    
    # set the headers for the API request to search for the film
    headers = {
        'authority': 'www.ktuvit.me',
        'accept': 'application/json, text/javascript, */*; q=0.01',
        'x-requested-with': 'XMLHttpRequest',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36',
        'content-type': 'application/json',
        'origin': 'https://www.ktuvit.me',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-mode': 'cors',
        'sec-fetch-dest': 'empty',
        'referer': 'https://www.ktuvit.me/Search.aspx',
        'accept-language': 'en-US,en;q=0.9',
    }

    # create the data payload for the API request to search for the film
    data = '{"request":{"FilmName":"%s","Actors":[],"Studios":null,"Directors":[],"Genres":[],"Countries":[],"Languages":[],"Year":"","Rating":[],"Page":1,"SearchType":"%s","WithSubsOnly":false}}'%(s_title,s_type)
    
    # send the API request to search for the film and parse the response
    response = requests.post('https://www.ktuvit.me/Services/ContentProvider.svc/SearchPage_search', headers=headers, data=data).json()
    
    # extract the film ID from the response using the imdb_id
    j_data=json.loads(response['d'])['Films']
    f_id=''
    for itt in j_data:
        if imdb_id==itt['ImdbID']:
            f_id=itt['ID']
    
    # if the film ID is found, set the URL to search for subtitles
    if f_id!='':
        url='https://www.ktuvit.me/MovieInfo.aspx?ID='+f_id
    else:
        return []
        
    # if searching for a TV show, set the headers and params for the API request to search for subtitles
    if "tvshow" in item:
        if item["tvshow"]:
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:81.0) Gecko/20100101 Firefox/81.0',
                'Accept': 'text/html, */*; q=0.01',
                'Accept-Language': 'en-US,en;q=0.5',
                'X-Requested-With': 'XMLHttpRequest',
                'Connection': 'keep-alive',
                'Referer': url,
                'Pragma': 'no-cache',
                'Cache-Control': 'no-cache',
                'TE': 'Trailers',
            }

            params = (
                ('moduleName', 'SubtitlesList'),
                ('SeriesID', f_id),
                ('Season', item["season"]),
                ('Episode', item["episode"]),
            )

response = requests.get('https://www.ktuvit.me/Services/GetModuleAjax.ashx', headers=headers, params=params, cookies=login_cook).content
    # if searching for a movie, set the headers and params for the API request to search for subtitles
    else:
        headers = {
            'authority': 'www.ktuvit.me',
            'cache-control': 'max-age=0',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36',
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-user': '?1',
            'sec-fetch-dest': 'document',
            'referer': 'https://www.ktuvit.me/MovieInfo.aspx?ID='+f_id,
            'accept-language': 'en-US,en;q=0.9',
        }
        params = (
            ('ID', f_id),
        )
        response = requests.get('https://www.ktuvit.me/MovieInfo.aspx', headers=headers, params=params, cookies=login_cook).content
        
    # extract the subtitle data from the response and add it to the subtitle list
    regex='<tr>(.+?)</tr>'
    m_pre=re.compile(regex,re.DOTALL).findall(response.decode('utf-8'))
    z=0
    subtitle=' '
    for itt in m_pre:
        regex='<div style="float.+?>(.+?)<br />.+?data-subtitle-id="(.+?)"'
        m=re.compile(regex,re.DOTALL).findall(itt)
        if len(m)==0:
            continue
        nm=m[0][0].replace('\n','').replace('\r','').replace('\t','').replace(' ','')
        data='{"request":{"FilmID":"%s","SubtitleID":"%s","FontSize":0,"FontColor":"","PredefinedLayout":-1}}'%(f_id,m[0][1])
        subtitle_list.append(nm)
        if check_one==True:
            break
        links_first=subtitle_list
        z=z+1
        
    return subtitle_list
    
    
def Caching(filename,url):    
    # Define a function called 'Caching' that takes a filename and URL as input parameters.
    
    try:
      # Try to get the JSON data from the URL and store it in a variable called 'x'.
      x=requests.get(url).json()
    except:
      # If there is an error, set 'x' to an empty dictionary and continue with the code.
      x={}
      pass
    # Return the 'x' dictionary.
    return x
    
def GetJson(imdb, mode_subtitle, season=0, episode=0, version=0, check_one=False, global_var=[]):
    # Define a function called 'GetJson' that takes several input parameters.
    
    global links_wizdom
    # Declare a global variable called 'links_wizdom'.

    filename = 'wizdom.imdb.%s.%s.%s.json'%(imdb, season, episode)
    # Create a filename based on the input parameters.

    url = "http://wizdom.xyz/api/search?action=by_id&imdb=%s&season=%s&episode=%s&version=%s"%(imdb, season, episode, version)
    # Create a URL based on the input parameters.
    
    json_object = Caching(filename, url)
    # Use the 'Caching' function to get JSON data and store it in 'json_object'.
    
    subs_rate = []
    subtitle=' '
    x=0
    id_all_collection=[]
    subtitle_list=global_var
    
    if json_object!=0:
        # If the JSON object is not empty, loop through each item in the object.
        for item_data in json_object:
       
            if item_data["id"] not in id_all_collection:
                # If the item's ID is not already in the collection, add it to the collection.
                id_all_collection.append(item_data["id"])
                if item_data["versioname"] in subtitle_list:
                    # If the item's version name is already in the subtitle list, skip it.
                    continue
                subtitle_list.append(item_data["versioname"])
                # Otherwise, add the item's version name to the subtitle list.

                if check_one==True:
                              break
                links_wizdom=subtitle_list
                # If the 'check_one' parameter is True, break the loop and set 'links_wizdom' to the subtitle list.
                x=x+1

    if (json_object)==0:
      # If the JSON object is empty, return 0 and an empty string and subtitle list.
      return 0,' ',subtitle_list
    else:
      # Otherwise, return the subtitle list.
      return subtitle_list

def lowercase_with_underscores(str):
    # Define a function called 'lowercase_with_underscores' that takes a string as an input parameter.
    
    from unicodedata import normalize
    # Import the 'normalize' function from the 'unicodedata' module.
    
    return normalize('NFKD', (str)).encode('utf-8', 'ignore')
    # Normalize the string and encode it as UTF-8.

def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id,check_one=False):
    global global_var,stop_all  # declaring global variables
    import xbmcvfs  # importing the xbmcvfs module
    xbmc_tranlate_path=xbmcvfs.translatePath  # assigning the translatePath function to the xbmc_translate_path variable
    import xmlrpc.client as xc  # importing the xmlrpc.client module and renaming it to xc
    xmlserver=xc.Server  # assigning the Server function to the xmlserver variable
    langs = []  # initializing an empty list named langs
    langDict = {'Hebrew': 'heb'}  # creating a dictionary with 'Hebrew' as key and 'heb' as value
    
    try:
        try: langs = langDict['Hebrew'].split(',')  # checking if 'Hebrew' is present in langDict and splitting it with ',' if it is
        except: langs.append(langDict['Hebrew'])  # if 'Hebrew' is not present in langDict, then append it to langs
    except: pass  # if an error occurs during the try block, ignore it and pass
    
    item={}  # initializing an empty dictionary named item
    
    da=[]  # initializing an empty list named da
    da.append((tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id,check_one))  # appending a tuple containing the function parameters to da
    
    if tv_movie=='movie':  # if tv_movie is equal to 'movie'
      item["movie"]=original_title.replace("%20"," ").replace("%27","'")  # replace "%20" with a space and "%27" with an apostrophe in the original_title and assign the result to the 'movie' key of item
    else:  # otherwise
      item["tvshow"]=original_title.replace("%20"," ").replace("%27","'")  # replace "%20" with a space and "%27" with an apostrophe in the original_title and assign the result to the 'tvshow' key of item
    if tv_movie=='tv':  # if tv_movie is equal to 'tv'
      imdbid_data='https://api.themoviedb.org/3/tv/%s?api_key=34142515d9d23817496eeb4ff1d223d0&append_to_response=external_ids'%id  # create a URL with the id and api_key for a TV show from themoviedb API and assign it to imdbid_data
    else:  # otherwise
      imdbid_data='https://api.themoviedb.org/3/movie/%s?api_key=34142515d9d23817496eeb4ff1d223d0&append_to_response=external_ids'%id  # create a URL with the id and api_key for a movie from themoviedb API and assign it to imdbid_data

    x=requests.get(imdbid_data).json()  # send a GET request to imdbid_data and convert the response to JSON format
    
    try:
        imdbid=x['external_ids']['imdb_id']  # extract the imdb_id from the JSON response and assign it to imdbid
        if imdbid==None:  # if imdbid is None
          imdbid=''  # assign an empty string to imdbid
    except:
      imdbid=''  # if an error occurs during the try block, assign an empty string to imdbid
    
    item['title']=original_title.replace("%20"," ").replace("%27","'")  # replace "%20" with a space and "%27" with an apostrophe in the original_title and assign the result to the 'title' key of item
  
    item["season"]=season  # assign the value of season to the 'season' key of item
    item["episode"]=episode  # assign the value of episode to the 'episode' key of item
    item["year"]=show_original_year  # assign the value of show_original_year to the 'year' key of item
    subtitle_list=[]  # initializing an empty list named subtitle_list

    fixed_list=[]  # initializing an empty list named fixed_list
    global_var1=''  # initializing an empty string named global_var1
    global_var2=''  # initializing an empty string named global_var2
    global_var3=''  # initializing an empty string named global_var3
    try:
        global_var1=(FirstPlace_Search(item,imdbid,subtitle_list,check_one))  # calling the function FirstPlace_Search with item, imdbid, subtitle_list, and check_one as arguments and assigning the result to global_var1

    except Exception as e:
        # logging.warning('Error in screwzira:'+str(e))
        pass
    
    # if check_one==True:
      
      # if len (global_var)>0:
        # return global_var
    
    try:
        global_var2=GetJson(imdbid,'1',season=season,episode=episode,version=lowercase_with_underscores(item['title']),check_one=check_one,global_var=global_var)  # calling the function GetJson with imdbid, '1', season, episode, lowercase_with_underscores(item['title']), check_one, and global_var as arguments and assigning the result to global_var2
    except Exception as e:
        # logging.warning('Error in wizdom:'+str(e))
        pass
    # try:
        # for items in result:
            # fixed_list.append((items['MovieReleaseName']))

        # global_var3=fixed_list
    # except Exception as e:
        # log.warning('Error in opensubtitles:'+str(e))
        # pass
    
    global_var=global_var1+global_var2#+global_var3  # concatenate global_var1 and global_var2 and assign the result to global_var
    return global_var  # return global_var

