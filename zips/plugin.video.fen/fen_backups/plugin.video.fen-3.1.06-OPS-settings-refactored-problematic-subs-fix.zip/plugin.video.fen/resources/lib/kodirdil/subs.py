########### Imports #####################
from modules import kodi_utils
import json
import re,requests
from collections import OrderedDict
from modules.kodi_utils import hebrew_subtitles_db, database

# Import hebrew subtitle search functions
from kodirdil.websites import ktuvit
from kodirdil.websites import wizdom
from kodirdil.websites import opensubtitles
#########################################

########### Constants ###################
websites_info = {
    'ktuvit': {'website': ktuvit, 'short_name': '[KT]'},
    'wizdom': {'website': wizdom, 'short_name': '[WIZ]'},
    'opensubtitles': {'website': opensubtitles, 'short_name': '[OPS]'}
}
#########################################

def search_hebrew_subtitles_for_selected_media(media_type, title, season, episode, year, tmdb_id):

    """
    Search for Hebrew subtitles for a selected media and write the filtered subtitles to a cache table.
    
    Args:    
    media_type: The type of media ('movie' or 'tv').
    title: The title of the media.
    season: The season number for TV shows.
    episode: The episode number for TV shows.
    year: The release year of the media.
    tmdb_id: The ID of the media in the TMDB database.

    Returns:
    None
    """
    
    media_metadata = {
        "media_type": media_type,
        "title": title.replace("%20"," ").replace("%27","'"),
        "season": season,
        "episode": episode,
        "year": year,
        "tmdb_id": tmdb_id,
        "imdb_id": get_imdb_id(media_type, tmdb_id)
    }
    

    # Used to solve the problmetic subtitles with short name. Example: top.gun.maverick.2022.srt
    stripped_media_name = strip_media_name(media_type, media_metadata, season, episode, year)
    stripped_media_name_length = len(stripped_media_name)
    kodi_utils.logger("KODI-RD-IL", f"stripped_media_name_length: {stripped_media_name_length}")
    kodi_utils.logger("KODI-RD-IL", f"###########################################################################################")
    
    # Search for subtitles in all websites and combine them into a single list
    combined_subtitles_list = []
    website_subtitles_dict = {}
    for website_info in websites_info.values():
        try:
            hebrew_subtitles_list = website_info['website'].search_hebrew_subtitles(media_metadata)
            website_subtitles_dict[website_info['short_name']] = hebrew_subtitles_list
            kodi_utils.logger("KODI-RD-IL", f"{website_info['short_name']}_subtitles_list: {str(hebrew_subtitles_list)}")   
            combined_subtitles_list.extend(hebrew_subtitles_list)
            
        except Exception as e:
            kodi_utils.logger("KODI-RD-IL", f"Error in searching subtitles from {website_info['website']}: {str(e)}")
    
    # Convert the combined list to an OrderedDict to remove duplicates while preserving order
    unique_subtitles_dict = OrderedDict.fromkeys(combined_subtitles_list)
    
    # Convert the set back to a list
    unique_subtitles_list = list(unique_subtitles_dict.keys())
    kodi_utils.logger("KODI-RD-IL", f"unique_subtitles_list: {str(unique_subtitles_list)}")
    
    # Filter the unique subtitles list to only include subtitles whose name length is greater than stripped_media_name_length
    filtered_subtitles_list = [subtitle_name for subtitle_name in unique_subtitles_list if len(clean_string(subtitle_name)) > stripped_media_name_length]
        
    # Write the filtered subtitles list to the hebrew_subtitles_db cache table if it is not empty
    write_unique_subtitles_to_subs_db(filtered_subtitles_list, website_subtitles_dict)
  
  
def write_unique_subtitles_to_subs_db(filtered_subtitles_list, website_subtitles_dict):

    """
    Write unique subtitles from `filtered_subtitles_list` to the 'current_subtitles_cache' table in 'subs.db'.

    Args:
    filtered_subtitles_list (list): A list of unique subtitles to be written to the database.
    website_subtitles_dict (dict): A dictionary containing website short names as keys and corresponding subtitle lists as values.

    Returns:
    None
    """
    
    # Clear the cache table in the database before writing new subtitles
    clear_hebrew_subtitles_db_cache()
    
    try:
        # Connect to the database and create a cursor
        dbcon = database.connect(hebrew_subtitles_db)
        dbcur = dbcon.cursor()
        
        if filtered_subtitles_list:
            # Iterate through each subtitle in `filtered_subtitles_list`
            for subtitle_name in filtered_subtitles_list:
                website_name = None
                for website_short_name, website_subtitles_list in website_subtitles_dict.items():
                    if subtitle_name in website_subtitles_list:
                        website_name = website_short_name
                        break
                if website_name:
                    # Insert the subtitle and website name into the cache table
                    dbcur.execute("INSERT INTO current_subtitles_cache Values ('%s','%s')"%(subtitle_name, website_name))
                    dbcon.commit()
                    
            # Close the database connection
            dbcon.close()
            
            kodi_utils.logger("KODI-RD-IL", f"filtered_subtitles_list: {str(filtered_subtitles_list)}")
            
        else:
            kodi_utils.logger("KODI-RD-IL", "filtered_subtitles_list is empty.")
            
    except Exception as e:
        kodi_utils.logger("KODI-RD-IL", f"Error in writing subtitles to hebrew_subtitles_db: {str(e)}")
    
       
# Define the function to get the total subtitles found list
def get_total_subtitles_found_list():

    """
    This function connects to the 'hebrew_subtitles_db' database and retrieves a list of all the subtitles found in the
    'current_subtitles_cache' table. If there are no subtitles found, an empty list is returned. If there is an error while
    reading the database, an error message is logged and an empty list is returned.

    Returns:
    total_subtitles_found_list: A list of all the subtitles found in the 'current_subtitles_cache' table.

    """
    try:
        # Connect to the database and get the current subtitles cache
        dbcon = database.connect(hebrew_subtitles_db)
        dbcur = dbcon.cursor()
        dbcur.execute("SELECT * FROM current_subtitles_cache")
        total_subtitles_found_list = dbcur.fetchall()

        # If there are subtitles found in the cache, get the count
        if not total_subtitles_found_list:
            return []
            
        return total_subtitles_found_list
        
    except Exception as e:
        # Log any errors that occur while reading the database
        kodi_utils.logger("KODI-RD-IL", f"Error while reading hebrew_subtitles_db and setting total_subtitles_found_count parameter: {str(e)}")
        return []
          

def clean_media_title_string(media_title):
    """Converts a media title string to a standardized format.

    Args:
    media_title (str): The media title string to be cleaned.

    Returns:
    str: A cleaned version of the media title string with all characters in lower case and special characters replaced with periods.

    Example:
    >>> clean_media_title_string("The Great Gatsby%20(2013)")
    'the.great.gatsby.2013'
    """
    return media_title.lower().strip().replace("%20",".").replace("_",".").replace(" ",".").replace("-",".").replace("...",".").replace("..",".").replace("(","").replace(")","").replace("[","").replace("]","").replace(":","").replace(",","")


# Convert to lowercase, remove leading/trailing spaces, replace certain characters with dots, and remove video/audio formats.
def clean_string(string):
    """Cleans a string by converting to lowercase, removing leading/trailing spaces, and replacing certain characters with dots. Also removes common video and audio formats and language-specific subtitles.

    Args:
    string (str): The string to be cleaned.

    Returns:
    str: A cleaned version of the input string with all characters in lower case and special characters replaced with dots. Also removes common video and audio formats and language-specific subtitles.

    Example:
    clean_string("The Great Gatsby%20(2013)_Trailer.hebrew.srt")
    'the.great.gatsby.2013.trailer'
    """
    return string.lower().strip().replace("%20",".").replace("_",".").replace(" ",".").replace("-",".").replace("...",".").replace("..",".").replace("(","").replace(")","").replace("[","").replace("]","").replace(":","").replace(",","").replace(".avi","").replace(".mp4","").replace(".mkv","").replace(".dts","").replace(".truehd","").replace(".atmos","").replace(".aac","").replace(".x265","").replace(".x264","").replace(".7.1.1","").replace(".7.1","").replace(".5.1.1","").replace(".5.1","").replace(".hevc","").replace(".h.264","").replace(".h264","").replace(".h.265","").replace(".h265","").replace(".2160p","").replace(".1080p","").replace(".720p","").replace(".480p","").replace(".360p","").replace(".srt","").replace(".hebrew","").replace(".heb","")
    
    
def get_imdb_id(media_type, tmdb_id):

    """Retrieves the IMDb ID for a media item from its TMDb ID.

    Args:
    media_type (str): The type of media item, either 'movie' or 'tv'.
    tmdb_id (int): The TMDb ID of the media item.

    Returns:
    str: The IMDb ID of the media item, if available. Otherwise, an empty string is returned.

    Example:
    >>> get_imdb_id('movie', 12345)
    'tt1234567'
    """

    imdb_api_url = f'https://api.themoviedb.org/3/{media_type}/{tmdb_id}?api_key=34142515d9d23817496eeb4ff1d223d0&append_to_response=external_ids'
    try:
        imdb_api_reponse = requests.get(imdb_api_url).json()
        imdb_id = imdb_api_reponse['external_ids'].get('imdb_id', '')
        kodi_utils.logger("KODI-RD-IL", f"get_imdb_id function: TMDb ID: {tmdb_id} | IMDb ID: {imdb_id}")
        return imdb_id
    except Exception as e:
        kodi_utils.logger("KODI-RD-IL", f"Error in getting imdb_id from TMDb API: {str(e)}")
        return ''


def generate_subtitles_match_top_panel_text(total_subtitles_found_count, subtitles_matched_count):
    """Generates a text string for a Fen results top panel notification displaying the number of subtitles found and sources with 100% subtitle match.

    Args:
    total_subtitles_found_count (int): The total number of subtitles found.
    subtitles_matched_count (int): The number of sources with 100% subtitle match.

    Returns:
    str: A formatted string displaying the number of subtitles found and sources with 100% subtitle match.

    Example:
    >>> generate_subtitles_match_top_panel_text(10, 5)
    '[COLOR deepskyblue]נמצאו 10 כתוביות סך הכל[/COLOR] | [COLOR yellow]5 מקורות עם 100% התאמה לכתוביות[/COLOR] |'
    """
    if total_subtitles_found_count > 0:
        total_subtitles_found_text = f"[COLOR deepskyblue]נמצאו {total_subtitles_found_count} כתוביות סך הכל[/COLOR] | "
    else:
        total_subtitles_found_text = ""
        
    if subtitles_matched_count > 0:
        subtitles_matched_count_text = f"[COLOR yellow]{subtitles_matched_count} מקורות עם 100% התאמה לכתוביות[/COLOR] | "
    else:
        subtitles_matched_count_text = f"[COLOR yellow] לא נמצאו מקורות עם 100% התאמה לכתוביות[/COLOR] | "
        
    kodi_utils.logger("KODI-RD-IL", f"FEN sources with matched subtitles: {subtitles_matched_count}")
    
    return total_subtitles_found_text + subtitles_matched_count_text
    
    
def manage_search_hebrew_subtitles_thread(search_hebrew_subtitles_thread):

    """Manages the search_hebrew_subtitles_thread to prevent it from running indefinitely. This function checks if the thread is still running and if so, waits for 200ms before checking again. This process is repeated until the thread has finished running or if it runs longer than 10 seconds, at which point the function forcibly stops the thread. The function logs messages to the Kodi log to indicate the status of the thread.

    Args:
    search_hebrew_subtitles_thread (threading.Thread): The thread to be managed.

    Returns:
    None

    Example:
    To manage the search_hebrew_subtitles_thread, call this function and pass in the thread object:
    >>> manage_search_hebrew_subtitles_thread(search_hebrew_subtitles_thread)
    """
    
    try:
        count = 0
        while search_hebrew_subtitles_thread is not None and search_hebrew_subtitles_thread.is_alive():
            kodi_utils.logger("KODI-RD-IL", "search_hebrew_subtitles_thread SLEEP - search_hebrew_subtitles_thread is still alive. sleeping 200ms...")
            kodi_utils.sleep(200)
            count += 1
            if count > 100:
                kodi_utils.logger("KODI-RD-IL", "search_hebrew_subtitles_thread FORCE STOP - search_hebrew_subtitles_thread runs longer than 10 seconds. stopping the thread...")
                break
        kodi_utils.logger("KODI-RD-IL", "search_hebrew_subtitles_thread END - search_hebrew_subtitles_thread has finished.")
    except Exception as e:
        kodi_utils.logger("KODI-RD-IL", f"search_hebrew_subtitles_thread ERROR - Error managing search_hebrew_subtitles_thread loop: {str(e)}")
        
        
def create_search_hebrew_subtitles_thread(media_type, title, season, episode, year, tmdb_id):

    """Creates a thread to search for Hebrew subtitles for a media item.

    Args:
    media_type (str): The type of media item, either 'movie' or 'tv'.
    title (str): The title of the media item.
    season (int): The season number for a TV show, or 0 for a movie.
    episode (int): The episode number for a TV show, or 0 for a movie.
    year (int): The year the media item was released.
    tmdb_id (int): The TMDb ID of the media item.

    Returns:
    threading.Thread: The created thread for searching Hebrew subtitles.

    Example:
    >>> create_search_hebrew_subtitles_thread('tv', 'Breaking Bad', 1, 1, 2008, 12345)
    """

    if media_type == 'movie':
        hebrew_subtitles_search_arguments = ('movie', title, '0', '0', year, tmdb_id)
        kodi_utils.logger("KODI-RD-IL", f"search_hebrew_subtitles_thread START - Calling search_hebrew_subtitles_for_selected_media() for Movie: {title} | Year: {year} | TMDb ID: {tmdb_id})")
    else:
        hebrew_subtitles_search_arguments = ('tv', title, season, episode, year, tmdb_id)
        kodi_utils.logger("KODI-RD-IL", f"search_hebrew_subtitles_thread START - Calling search_hebrew_subtitles_for_selected_media() for TV Show: {title} Season {season} Episode {episode} | Year: {year} | TMDb ID: {tmdb_id})")
    
    try:
        search_hebrew_subtitles_thread = kodi_utils.Thread(target=search_hebrew_subtitles_for_selected_media, args=hebrew_subtitles_search_arguments)
        return search_hebrew_subtitles_thread
        
    except Exception as e:
        kodi_utils.logger("KODI-RD-IL", f"Error while creating search_hebrew_subtitles_thread and calling search_hebrew_subtitles_for_selected_media(): {str(e)}")
        return None


def clear_hebrew_subtitles_db_cache():

    """
    Creates the 'current_subtitles_cache' table in 'hebrew_subtitles_db' if it doesn't exist and clears its contents.
    This function first creates a table called 'current_subtitles_cache' in the 'hebrew_subtitles_db' if it doesn't exist. Then it clears all the contents of the table, effectively clearing the cache.

    Args:
    None

    Returns:
    None
    """
    
    try:
        dbcon = database.connect(hebrew_subtitles_db)
        dbcur = dbcon.cursor()
        
        # Create hebrew_subtitles_db if not exist
        dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""subtitle_name TEXT ,""website_name TEXT);" % ('current_subtitles_cache'))
        dbcon.commit()
        
        # Clear hebrew_subtitles_db
        dbcon.execute("DELETE FROM current_subtitles_cache")
        dbcon.commit()
        
        dbcon.close()
        kodi_utils.logger("KODI-RD-IL", "Cleared hebrew_subtitles_db cache")
        
    except Exception as e:
        kodi_utils.logger("KODI-RD-IL", f"Error Clearing hebrew_subtitles_db cache: {str(e)}")
        
        
def clear_fen_providers_cache():

    """Clears the cache for FEN providers by deleting the `providers.db` file used by the FEN Kodi addon.
    
    Args:
        None

    Returns:
        None
    """
    # Clear providers cache
    try:
        from caches.providers_cache import ExternalProvidersCache
        ExternalProvidersCache().delete_cache(silent=True)
        kodi_utils.logger("KODI-RD-IL", "Cleared providers.db cache")
    except Exception as e:
        kodi_utils.logger("KODI-RD-IL", f"Error clearing providers.db cache: {str(e)}")
    
    
def strip_media_name(media_type, media_metadata, season, episode, year):
    """Strips the media name based on the media type and returns the result.

    Args:
    media_type (str): The type of media item, either 'movie' or 'tv'.
    media_metadata (dict): A dictionary containing metadata for the media item, including its title.
    season (int): The season number for a TV show, or 0 for a movie.
    episode (int): The episode number for a TV show, or 0 for a movie.
    year (int): The year the media item was released.

    Returns:
    str: A stripped version of the media name, with special characters replaced with periods and appended with season and episode numbers for TV shows or the year for movies.

    Example:
    >>> strip_media_name('tv', {'title': 'Breaking Bad'}, 1, 1, 2008)
    'breaking.bad.s01.e01'
    """
    
    # Strip the media name and log the result
    if media_type == 'movie':
        kodi_utils.logger("KODI-RD-IL", f"###########################################################################################")
        kodi_utils.logger("KODI-RD-IL", f"BEFORE STRIP - Movie Title + Year: {media_metadata['title']} | {year}")
        stripped_media_name = f"{clean_media_title_string(media_metadata['title'])}.{year}"
        kodi_utils.logger("KODI-RD-IL", f"AFTER STRIP - Movie Title + Year: {stripped_media_name}")
        
    else:
        kodi_utils.logger("KODI-RD-IL", f"###########################################################################################")
        kodi_utils.logger("KODI-RD-IL", f"BEFORE STRIP - TV Show Title + Season + Episode: {media_metadata['title']} | {season} | {episode}")
        stripped_media_name = f"{clean_media_title_string(media_metadata['title'])}.s{season:02d}.e{episode:02d}"
        kodi_utils.logger("KODI-RD-IL", f"AFTER STRIP - TV Show Title + Season + Episode: {stripped_media_name}")
    
    return stripped_media_name
