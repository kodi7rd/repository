########### Imports #####################
from modules import kodi_utils
import requests
import json
from collections import OrderedDict

########### KODI-RD-IL Imports ##########
from kodirdil import string_utils
from kodirdil import db_utils
# Import hebrew subtitle search functions
from kodirdil.websites import ktuvit
from kodirdil.websites import wizdom
from kodirdil.websites import opensubtitles
#########################################

########### Settings ####################
filter_problematic_subtitle_names = kodi_utils.get_setting('filter_problematic_subtitle_names', 'true') == 'true'
minimum_sync_percent = int(kodi_utils.get_setting('minimum_hebrew_subtitles_sync_percentage_match_slider', '85'))
#########################################

########### Constants ###################
hebrew_subtitles_websites_info = {
    'ktuvit': {'website': ktuvit, 'short_name': '[KT]'},
    'wizdom': {'website': wizdom, 'short_name': '[WIZ]'},
    'opensubtitles': {'website': opensubtitles, 'short_name': '[OPS]'}
    }
    
# Loki:                 
# release_names = ['bluray','hdtv','dvdrip','bdrip','web-dl','hdcam','hdrip','webrip']
# Burkeas:
release_names = ['blueray','bluray','blu-ray','bdrip','brrip','brip',
                 'hdtv','hdtvrip','pdtv','tvrip','hdrip','hd-rip',
                 'web','web-dl','web dl','web-dlrip','webrip','web-rip',
                 'dvdr','dvd-r','dvd-rip','dvdrip','cam','hdcam','cam-rip','camrip','screener','dvdscr','dvd-full',
                 'telecine','hdts','telesync']
#########################################

def search_hebrew_subtitles_for_selected_media(media_type, title, season, episode, year, tmdb_id):

    """
    Search for Hebrew subtitles for a selected media and write the filtered subtitles to a cache table.
    
    Args:    
    media_type: The type of media ('movie' or 'tv').
    title: The title of the media.
    season: The season number for TV shows.
    episode: The episode number for TV shows.
    year: The release year of the media.
    tmdb_id: The ID of the media in the TMDB database.

    Returns:
    None
    """
    
    media_metadata = {
        "media_type": media_type,
        "title": title.replace("%20"," ").replace("%27","'"),
        "season": season,
        "episode": episode,
        "year": year,
        "tmdb_id": tmdb_id,
        "imdb_id": get_imdb_id(media_type, tmdb_id)
    }
    
    kodi_utils.logger("KODI-RD-IL", f"###########################################################################################")
    
    # Search for subtitles in all websites and combine them into a single list
    combined_subtitles_list = []
    website_subtitles_dict = {}
    for website_info in hebrew_subtitles_websites_info.values():
        try:
            hebrew_subtitles_list = website_info['website'].search_hebrew_subtitles(media_metadata)
            website_subtitles_dict[website_info['short_name']] = hebrew_subtitles_list
            combined_subtitles_list.extend(hebrew_subtitles_list)
            kodi_utils.logger("KODI-RD-IL", f"{website_info['short_name']}_subtitles_list: {str(hebrew_subtitles_list)}")   
            kodi_utils.logger("KODI-RD-IL", f"###########################################################################################")
            
        except Exception as e:
            kodi_utils.logger("KODI-RD-IL", f"Error in searching subtitles from {website_info['website']}: {str(e)}")
            kodi_utils.logger("KODI-RD-IL", f"###########################################################################################")
    
    # Convert the combined list to an OrderedDict to remove duplicates while preserving order
    unique_subtitles_dict = OrderedDict.fromkeys(combined_subtitles_list)
    
    # Convert the set back to a list
    unique_subtitles_list = list(unique_subtitles_dict.keys())
    kodi_utils.logger("KODI-RD-IL", f"unique_subtitles_list BEFORE problematic subtitles filter: {str(unique_subtitles_list)}")
    kodi_utils.logger("KODI-RD-IL", f"###########################################################################################")
    
    # Problematic Subtitles Filtering (if filter_problematic_subtitle_names setting enabled)
    log_message = "Filtering problematic subtitles..." if filter_problematic_subtitle_names else "Skipping filtering problematic subtitles..."
    kodi_utils.logger("KODI-RD-IL", f"SETTING filter_problematic_subtitle_names is: {filter_problematic_subtitle_names}. {log_message}")
    if filter_problematic_subtitle_names:
        unique_subtitles_list = filter_problematic_subtitle_names_list(unique_subtitles_list, media_type, title, season, episode, year)
        kodi_utils.logger("KODI-RD-IL", f"unique_subtitles_list AFTER problematic subtitles filter: : {str(unique_subtitles_list)}")
    
    # Write the unique subtitles list to the hebrew_subtitles_db cache table if it is not empty
    db_utils.write_unique_subtitles_to_hebrew_subtitles_db(unique_subtitles_list, website_subtitles_dict)
  
 
def filter_problematic_subtitle_names_list(unique_subtitles_list, media_type, title, season, episode, year):

    """
    Filter a list of subtitles to remove problematic ones with short names.

    Args:
        unique_subtitles_list (list): A list of unique subtitle names.
        media_type (str): The type of media (e.g., movie, tvshow).
        title (str): The title of the media.
        season (str): The season of the media (if applicable).
        episode (str): The episode of the media (if applicable).
        year (str): The year of the media (if applicable).

    Returns:
        list: A filtered list of subtitles that have a name length greater than the length of the stripped media name.

    Example: top.gun.maverick.2022.srt
    """
    
    stripped_media_name = string_utils.strip_media_name(media_type, title, season, episode, year)
    stripped_media_name_length = len(stripped_media_name)
    kodi_utils.logger("KODI-RD-IL", f"stripped_media_name_length: {stripped_media_name_length}")
    kodi_utils.logger("KODI-RD-IL", f"###########################################################################################")
    
    # Filter the unique subtitles list to only include subtitles whose name length is greater than stripped_media_name_length
    return [subtitle_name for subtitle_name in unique_subtitles_list if len(string_utils.clean_string(subtitle_name)) > stripped_media_name_length]
    
    
def get_imdb_id(media_type, tmdb_id):

    """Retrieves the IMDb ID for a media item from its TMDb ID.

    Args:
    media_type (str): The type of media item, either 'movie' or 'tv'.
    tmdb_id (int): The TMDb ID of the media item.

    Returns:
    str: The IMDb ID of the media item, if available. Otherwise, an empty string is returned.

    Example:
    >>> get_imdb_id('movie', 12345)
    'tt1234567'
    """

    imdb_api_url = f'https://api.themoviedb.org/3/{media_type}/{tmdb_id}?api_key=34142515d9d23817496eeb4ff1d223d0&append_to_response=external_ids'
    try:
        imdb_api_reponse = requests.get(imdb_api_url).json()
        imdb_id = imdb_api_reponse['external_ids'].get('imdb_id', '')
        kodi_utils.logger("KODI-RD-IL", f"get_imdb_id function: TMDb ID: {tmdb_id} | IMDb ID: {imdb_id}")
        return imdb_id
    except Exception as e:
        kodi_utils.logger("KODI-RD-IL", f"Error in getting imdb_id from TMDb API: {str(e)}")
        return ''
        

def generate_subtitles_match_top_panel_text_for_sync_percent_match(total_subtitles_found_count, subtitles_matched_count):
    """Generates a text string for a Fen results top panel notification displaying the number of subtitles found and sources with 100% subtitle match.

    Args:
    total_subtitles_found_count (int): The total number of subtitles found.
    subtitles_matched_count (int): The number of sources with 100% subtitle match.

    Returns:
    str: A formatted string displaying the number of subtitles found and sources with 100% subtitle match.

    Example:
    >>> generate_subtitles_match_top_panel_text(10, 5)
    '[COLOR deepskyblue]נמצאו 10 כתוביות סך הכל[/COLOR] | [COLOR yellow]5 מקורות עם 100% התאמה לכתוביות[/COLOR] |'
    """
    if total_subtitles_found_count > 0:
        total_subtitles_found_text = f"[COLOR deepskyblue]נמצאו {total_subtitles_found_count} כתוביות סך הכל[/COLOR] | "
    else:
        total_subtitles_found_text = ""
        
    if subtitles_matched_count > 0:
        subtitles_matched_count_text = f"[COLOR yellow]{subtitles_matched_count} מקורות מעל {minimum_sync_percent}% התאמה לכתוביות[/COLOR] | "
    else:
        subtitles_matched_count_text = f"[COLOR yellow]לא נמצאו מקורות מעל {minimum_sync_percent}% התאמה לכתוביות[/COLOR] | "
        
    kodi_utils.logger("KODI-RD-IL", f"FEN sources with matched subtitles: {subtitles_matched_count}")
    kodi_utils.logger("KODI-RD-IL", f"###########################################################################################")
    
    return total_subtitles_found_text + subtitles_matched_count_text
    
    
def calculate_highest_sync_percent_and_set_match_text(total_subtitles_found_list, original_fen_source_file_name, quality):

    subtitles_matched_count = 0
    subtitle_matches_text = ""

    highest_sync_percent, matched_subtitle_website_name  = calculate_highest_sync_percent_between_subtitles_and_fen_source(total_subtitles_found_list, original_fen_source_file_name, quality)
    
    if highest_sync_percent >= minimum_sync_percent:
        subtitles_matched_count = 1
        subtitle_matches_text = f"[B][COLOR deepskyblue]  SUBTITLE: [/COLOR][COLOR yellow]{matched_subtitle_website_name} {highest_sync_percent}% התאמה של[/COLOR][/B]"
        
    return subtitles_matched_count, subtitle_matches_text


def calculate_highest_sync_percent_between_subtitles_and_fen_source(total_subtitles_found_list, original_fen_source_file_name, quality):

    ########## Calc Percent and Langauge Sort ##########
    kodi_utils.logger("KODI-RD-IL", f"###########################################################################################")
    kodi_utils.logger("KODI-RD-IL", f"BEFORE ARRAY - Original FEN File Name: {original_fen_source_file_name}")

    # Reformat quality from Fen to correct format.
    quality_mapping = {
        "4K": "2160p",
        "SD": "480p"
    }
     # If no map found - get default quality value. (1080p / 720p)
    quality = quality_mapping.get(quality, quality)
    
    array_fen_source_file_name = original_fen_source_file_name.strip().replace("_",".").replace(" ",".").replace("+",".").replace("/",".").replace(".avi","").replace(".mp4","").replace(".mkv","").split(".")
    kodi_utils.logger("KODI-RD-IL", f"AFTER STRIP AND REPLACE - array_fen_source_file_name: {array_fen_source_file_name}")

    highest_sync_percent = 0
    matched_subtitle_name = ""
    matched_subtitle_website_name = ""
    
    for subtitle_element in total_subtitles_found_list:
    
        subtitle_name, subtitle_website_name = subtitle_element
        
        kodi_utils.logger("KODI-RD-IL", f"Calculating sync percentage match for subtitle name: {subtitle_name}")
        # Calculate sync percentage between subtitle and FEN source file.
        sync_percent = calculate_sync_percent_between_subtitles_and_fen_source(subtitle_name, array_fen_source_file_name, quality)
        
        # Get highest sync percent from results
        if sync_percent > highest_sync_percent:
            highest_sync_percent = sync_percent
            matched_subtitle_name = subtitle_name
            matched_subtitle_website_name = subtitle_website_name
        kodi_utils.logger("KODI-RD-IL", f"###########################################################################################")
        
    kodi_utils.logger("KODI-RD-IL", f"HIGHEST SYNC PERCENT IS: {highest_sync_percent}% (BETWEEN FEN FILE NAME - {original_fen_source_file_name} AND SUBTITLE NAME - {matched_subtitle_name})")
    
    return highest_sync_percent, matched_subtitle_website_name

def calculate_sync_percent_between_subtitles_and_fen_source(subtitle_name, array_fen_source_file_name, quality):
    
    # Reset array_fen_source_file_name (remove quality / releases names)
    # Burekas:
    array_fen_source_file_name = [element.strip().lower() for element in array_fen_source_file_name if element != '']
    kodi_utils.logger("KODI-RD-IL", f"AFTER FIRST ELEMENTS REMOVAL - array_fen_source_file_name: {array_fen_source_file_name}")
    kodi_utils.logger("KODI-RD-IL", f"###########################################################################################")
    
    array_subtitle_name = subtitle_name.strip().replace(".srt",'').replace("_",".").replace(" ",".").replace("+",".").replace("/",".").split(".")
    kodi_utils.logger("KODI-RD-IL", f"AFTER STRIP AND REPLACE - array_subtitle_name: {array_subtitle_name}")
    
    array_subtitle_name=[element.strip().lower() for element in array_subtitle_name if element != '']
    kodi_utils.logger("KODI-RD-IL", f"AFTER FIRST ELEMENTS REMOVAL - array_subtitle_name: {array_subtitle_name}")

    if quality not in array_fen_source_file_name and quality in array_subtitle_name:
        array_fen_source_file_name.append(quality)
        kodi_utils.logger("KODI-RD-IL", f"AFTER QUALITY ADD - array_fen_source_file_name: {array_fen_source_file_name}")
        
    # Gives more weight to the ratio score to "release name" when comparing.
    for release_name in release_names:
    
        if release_name in array_fen_source_file_name and release_name in array_subtitle_name:
        
            kodi_utils.logger("KODI-RD-IL", f"RELEASE NAME MATCH - release_name: {release_name}")
            
            # Loki:
            array_fen_source_file_name.append(release_name)
            array_fen_source_file_name.append(release_name)
            array_fen_source_file_name.append(release_name)
            array_subtitle_name.append(release_name)
            array_subtitle_name.append(release_name)
            array_subtitle_name.append(release_name)
            
            kodi_utils.logger("KODI-RD-IL", f"RELEASE NAME ADD - array_subtitle_name: {array_subtitle_name}")
            kodi_utils.logger("KODI-RD-IL", f"RELEASE NAME ADD - array_fen_source_file_name: {array_fen_source_file_name}")


    sync_percent = string_utils.similar(array_fen_source_file_name, array_subtitle_name)
    kodi_utils.logger("KODI-RD-IL", f"CURRENT CHECK SYNC PERCENT IS: {sync_percent}%")
    
    return sync_percent