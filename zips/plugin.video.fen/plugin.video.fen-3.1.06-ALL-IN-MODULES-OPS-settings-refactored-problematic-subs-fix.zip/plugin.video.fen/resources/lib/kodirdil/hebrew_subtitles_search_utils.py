########### Imports #####################
from modules import kodi_utils
import requests
import json
from collections import OrderedDict

########### KODI-RD-IL Imports ##########
from kodirdil import string_utils
from kodirdil import db_utils
# Import hebrew subtitle search functions
from kodirdil.websites import ktuvit
from kodirdil.websites import wizdom
from kodirdil.websites import opensubtitles
#########################################

########### Constants ###################
hebrew_subtitles_websites_info = {
    'ktuvit': {'website': ktuvit, 'short_name': '[KT]'},
    'wizdom': {'website': wizdom, 'short_name': '[WIZ]'},
    'opensubtitles': {'website': opensubtitles, 'short_name': '[OPS]'}
}
#########################################

def search_hebrew_subtitles_for_selected_media(media_type, title, season, episode, year, tmdb_id):

    """
    Search for Hebrew subtitles for a selected media and write the filtered subtitles to a cache table.
    
    Args:    
    media_type: The type of media ('movie' or 'tv').
    title: The title of the media.
    season: The season number for TV shows.
    episode: The episode number for TV shows.
    year: The release year of the media.
    tmdb_id: The ID of the media in the TMDB database.

    Returns:
    None
    """
    
    media_metadata = {
        "media_type": media_type,
        "title": title.replace("%20"," ").replace("%27","'"),
        "season": season,
        "episode": episode,
        "year": year,
        "tmdb_id": tmdb_id,
        "imdb_id": get_imdb_id(media_type, tmdb_id)
    }
    

    # Used to solve the problmetic subtitles with short name. Example: top.gun.maverick.2022.srt
    stripped_media_name = string_utils.strip_media_name(media_type, title, season, episode, year)
    stripped_media_name_length = len(stripped_media_name)
    kodi_utils.logger("KODI-RD-IL", f"stripped_media_name_length: {stripped_media_name_length}")
    kodi_utils.logger("KODI-RD-IL", f"###########################################################################################")
    
    # Search for subtitles in all websites and combine them into a single list
    combined_subtitles_list = []
    website_subtitles_dict = {}
    for website_info in hebrew_subtitles_websites_info.values():
        try:
            hebrew_subtitles_list = website_info['website'].search_hebrew_subtitles(media_metadata)
            website_subtitles_dict[website_info['short_name']] = hebrew_subtitles_list
            kodi_utils.logger("KODI-RD-IL", f"{website_info['short_name']}_subtitles_list: {str(hebrew_subtitles_list)}")   
            combined_subtitles_list.extend(hebrew_subtitles_list)
            
        except Exception as e:
            kodi_utils.logger("KODI-RD-IL", f"Error in searching subtitles from {website_info['website']}: {str(e)}")
    
    # Convert the combined list to an OrderedDict to remove duplicates while preserving order
    unique_subtitles_dict = OrderedDict.fromkeys(combined_subtitles_list)
    
    # Convert the set back to a list
    unique_subtitles_list = list(unique_subtitles_dict.keys())
    kodi_utils.logger("KODI-RD-IL", f"unique_subtitles_list: {str(unique_subtitles_list)}")
    
    # Filter the unique subtitles list to only include subtitles whose name length is greater than stripped_media_name_length
    filtered_subtitles_list = [subtitle_name for subtitle_name in unique_subtitles_list if len(string_utils.clean_string(subtitle_name)) > stripped_media_name_length]
        
    # Write the filtered subtitles list to the hebrew_subtitles_db cache table if it is not empty
    db_utils.write_unique_subtitles_to_hebrew_subtitles_db(filtered_subtitles_list, website_subtitles_dict)
  
    
def get_imdb_id(media_type, tmdb_id):

    """Retrieves the IMDb ID for a media item from its TMDb ID.

    Args:
    media_type (str): The type of media item, either 'movie' or 'tv'.
    tmdb_id (int): The TMDb ID of the media item.

    Returns:
    str: The IMDb ID of the media item, if available. Otherwise, an empty string is returned.

    Example:
    >>> get_imdb_id('movie', 12345)
    'tt1234567'
    """

    imdb_api_url = f'https://api.themoviedb.org/3/{media_type}/{tmdb_id}?api_key=34142515d9d23817496eeb4ff1d223d0&append_to_response=external_ids'
    try:
        imdb_api_reponse = requests.get(imdb_api_url).json()
        imdb_id = imdb_api_reponse['external_ids'].get('imdb_id', '')
        kodi_utils.logger("KODI-RD-IL", f"get_imdb_id function: TMDb ID: {tmdb_id} | IMDb ID: {imdb_id}")
        return imdb_id
    except Exception as e:
        kodi_utils.logger("KODI-RD-IL", f"Error in getting imdb_id from TMDb API: {str(e)}")
        return ''


def subtitle_name_to_fen_source_file_name_matching(total_subtitles_found_list, name):

    """
    Matches the subtitle name with the FEN source file name.

    Args:
    - total_subtitles_found_list (list): A list of tuples containing subtitle names and website names.
    - name (str): The name of the FEN source file.

    Returns:
    - subtitles_matched_count (int): The count of matched subtitles. 
    - subtitle_matches_text (str): A string containing the details of matched subtitle, if any.
    """
    
    subtitles_matched_count = 0
    subtitle_matches_text = ''
    
    try:
        ############KODI-RD-IL###################
        # Iterate through the list of subtitle and website names
        for subtitle_name,website_name in total_subtitles_found_list:
            
            # Clean up the subtitle name and the source file name using the clean_string function
            current_subtitle_name = string_utils.clean_string(subtitle_name)
            fen_source_file_name = string_utils.clean_string(name)
            
            # Check if the cleaned up subtitle name is an exact match to the cleaned up source file name
            if current_subtitle_name == fen_source_file_name:
                
                kodi_utils.logger("KODI-RD-IL", f"###########################################################################################")
                kodi_utils.logger("KODI-RD-IL", f"{website_name} BEFORE STRIP - current_subtitle_name: {subtitle_name}")
                kodi_utils.logger("KODI-RD-IL", f"{website_name} BEFORE STRIP - fen_source_file_name: {name}")
            
                kodi_utils.logger("KODI-RD-IL", f"{website_name} AFTER STRIP - current_subtitle_name: {current_subtitle_name}")  
                kodi_utils.logger("KODI-RD-IL", f"{website_name} AFTER STRIP - fen_source_file_name: {fen_source_file_name}")
                
                kodi_utils.logger("KODI-RD-IL", f"{website_name} MATCH EQUAL: {current_subtitle_name} IN {fen_source_file_name}")
                kodi_utils.logger("KODI-RD-IL", f"###########################################################################################")
                
                # Set the subtitle matches text and count
                subtitles_matched_count = 1
                subtitle_matches_text = f"[B][COLOR deepskyblue]  SUBTITLE: [/COLOR][COLOR yellow]{(website_name)} התאמה של 100%[/COLOR][/B]"
                
                # Break out of the loop since we found a match
                break
            
            # Check if the cleaned up subtitle name is contained within the cleaned up source file name
            elif current_subtitle_name in fen_source_file_name:
                
                kodi_utils.logger("KODI-RD-IL", f"###########################################################################################")
                kodi_utils.logger("KODI-RD-IL", f"{website_name} BEFORE STRIP - current_subtitle_name: {subtitle_name}")
                kodi_utils.logger("KODI-RD-IL", f"{website_name} BEFORE STRIP - fen_source_file_name: {name}")
            
                kodi_utils.logger("KODI-RD-IL", f"{website_name} AFTER STRIP - current_subtitle_name: {current_subtitle_name}")  
                kodi_utils.logger("KODI-RD-IL", f"{website_name} AFTER STRIP - fen_source_file_name: {fen_source_file_name}")
                
                kodi_utils.logger("KODI-RD-IL", f"{website_name} MATCH INSIDE: {current_subtitle_name} IN {fen_source_file_name}")
                kodi_utils.logger("KODI-RD-IL", f"###########################################################################################")
                
                # Set the subtitle matches text and count
                subtitles_matched_count = 1
                subtitle_matches_text = f"[B][COLOR deepskyblue]  SUBTITLE: [/COLOR][COLOR yellow]{(website_name)} התאמה של 100%[/COLOR][/B]"
                
                # Break out of the loop since we found a match
                break

    except Exception as e:
        kodi_utils.logger("KODI-RD-IL", f"Error in subtitle matching: {e}")
        
    return subtitles_matched_count, subtitle_matches_text


def generate_subtitles_match_top_panel_text(total_subtitles_found_count, subtitles_matched_count):
    """Generates a text string for a Fen results top panel notification displaying the number of subtitles found and sources with 100% subtitle match.

    Args:
    total_subtitles_found_count (int): The total number of subtitles found.
    subtitles_matched_count (int): The number of sources with 100% subtitle match.

    Returns:
    str: A formatted string displaying the number of subtitles found and sources with 100% subtitle match.

    Example:
    >>> generate_subtitles_match_top_panel_text(10, 5)
    '[COLOR deepskyblue]נמצאו 10 כתוביות סך הכל[/COLOR] | [COLOR yellow]5 מקורות עם 100% התאמה לכתוביות[/COLOR] |'
    """
    if total_subtitles_found_count > 0:
        total_subtitles_found_text = f"[COLOR deepskyblue]נמצאו {total_subtitles_found_count} כתוביות סך הכל[/COLOR] | "
    else:
        total_subtitles_found_text = ""
        
    if subtitles_matched_count > 0:
        subtitles_matched_count_text = f"[COLOR yellow]{subtitles_matched_count} מקורות עם 100% התאמה לכתוביות[/COLOR] | "
    else:
        subtitles_matched_count_text = f"[COLOR yellow] לא נמצאו מקורות עם 100% התאמה לכתוביות[/COLOR] | "
        
    kodi_utils.logger("KODI-RD-IL", f"FEN sources with matched subtitles: {subtitles_matched_count}")
    
    return total_subtitles_found_text + subtitles_matched_count_text
    
    